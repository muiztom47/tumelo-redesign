import { Link, NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Home" },
  { to: "/fund-managers", label: "Fund managers" },
  { to: "/proxysphere", label: "ProxySphere" },
];

export default function Nav() {
  return (
    <header className="border-b border-rule">
      <div className="container-page flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5">
          <svg width="20" height="20" viewBox="0 0 32 32" aria-hidden="true">
            <rect width="32" height="32" fill="#152238" />
            <path
              d="M8 16.5l5 5 11-12"
              stroke="#A9822E"
              strokeWidth="2.6"
              fill="none"
              strokeLinecap="square"
            />
          </svg>
          <span className="font-serif text-lg font-medium tracking-tight text-ink">
            Tumelo
          </span>
        </Link>
        <nav className="hidden items-center gap-8 text-sm text-ink-light md:flex">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `border-b-2 pb-0.5 transition-colors ${
                  isActive
                    ? "border-brass text-ink"
                    : "border-transparent text-ink-soft hover:text-ink"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
        <a
          href="#contact"
          className="rounded-none border border-ink px-4 py-2 text-sm font-medium text-ink transition-colors hover:bg-ink hover:text-paper"
        >
          Speak to our team
        </a>
      </div>
    </header>
  );
}
