import VoteRecord from "../components/VoteRecord";

const features = [
  {
    title: "Voting-policy agnostic",
    body: "Investors aren't locked into one house policy. They pick from the broadest suite of voting policies, or vote resolution by resolution if they'd rather decide themselves.",
  },
  {
    title: "Proposal-theme filtering",
    body: "An investor who only cares about climate or remuneration resolutions can filter to just those, instead of wading through the full AGM agenda to find them.",
  },
  {
    title: "Built for pooled funds",
    body: "Works across institutional and retail investors sitting in the same fund, so operations doesn't need two separate systems for two investor types.",
  },
  {
    title: "No vote goes un-voted",
    body: "Shares default to a stated policy if an investor doesn't act, so the fund's voting record isn't full of silent abstentions nobody chose.",
  },
];

export default function ProxySphere() {
  return (
    <div>
      <section className="container-page grid gap-12 py-16 md:grid-cols-2 md:items-center md:py-24">
        <div>
          <p className="mb-4 text-xs uppercase tracking-wide text-brass-dark">
            Product · ProxySphere
          </p>
          <h1 className="font-serif text-4xl leading-[1.1] text-ink md:text-5xl">
            Pass-through voting, built for how pooled funds actually work.
          </h1>
          <p className="mt-6 max-w-measure text-base text-ink-light">
            ProxySphere puts the choice of how to vote back with the
            underlying investor, without asking your operations team to
            reconcile it by hand.
          </p>
          <a
            href="#contact"
            className="mt-8 inline-block border border-ink bg-ink px-5 py-3 text-sm font-medium text-paper hover:bg-ink-light"
          >
            Speak to our team
          </a>
        </div>
        <VoteRecord />
      </section>

      <section className="border-y border-rule bg-paper-raised py-20">
        <div className="container-page grid gap-x-16 gap-y-10 md:grid-cols-2">
          {features.map((f) => (
            <div key={f.title} className="border-t-2 border-ink pt-5">
              <h3 className="font-serif text-lg text-ink">{f.title}</h3>
              <p className="mt-2.5 text-sm text-ink-light">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-page py-20">
        <h2 className="max-w-measure font-serif text-2xl text-ink md:text-3xl">
          What it replaces
        </h2>
        <div className="mt-10 grid gap-px overflow-hidden border border-ink/15 bg-ink/15 md:grid-cols-2">
          <div className="bg-paper p-8">
            <p className="mb-3 text-xs uppercase tracking-wide text-ink-soft">
              Before
            </p>
            <ul className="space-y-3 text-sm text-ink-light">
              <li>A single house policy applied to every investor in the fund</li>
              <li>Voting instructions reconciled manually against holdings</li>
              <li>Retail investors with no visibility into how their shares voted</li>
            </ul>
          </div>
          <div className="bg-paper p-8">
            <p className="mb-3 text-xs uppercase tracking-wide text-brass-dark">
              With ProxySphere
            </p>
            <ul className="space-y-3 text-sm text-ink-light">
              <li>Each investor chooses a policy or votes resolution by resolution</li>
              <li>Instructions reconcile against holdings automatically</li>
              <li>Every investor can see exactly how their shares were voted</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
}
