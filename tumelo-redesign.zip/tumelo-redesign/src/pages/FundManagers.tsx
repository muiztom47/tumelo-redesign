const stats = [
  { value: "2018", label: "Building voting infrastructure since" },
  { value: "ISO 27001", label: "Accredited information security" },
  { value: "2", label: "Regulatory jurisdictions served (UK & US)" },
];

const workflow = [
  {
    step: "Before the meeting",
    title: "Resolutions land automatically",
    body: "Issuer filings and resolution text are pulled in as soon as they're published, matched to the holdings across every fund, and queued against your stewardship policy.",
  },
  {
    step: "During review",
    title: "Policy applies itself consistently",
    body: "The same climate, remuneration and governance policy gets applied to every resolution the same way, every meeting, so outcomes don't depend on who reviewed it that week.",
  },
  {
    step: "At the vote",
    title: "Investors see it, or you vote on their behalf",
    body: "Retail and institutional investors in the same pooled fund can view the resolution and vote directly, or default to the policy. Nothing is left unvoted.",
  },
  {
    step: "After the meeting",
    title: "The record is already built",
    body: "Vote instructions, outcomes and rationale are logged against each resolution as they happen, so year-end stewardship reporting isn't a separate research project.",
  },
];

export default function FundManagers() {
  return (
    <div>
      <section className="container-page py-16 md:py-24">
        <p className="mb-4 text-xs uppercase tracking-wide text-brass-dark">
          For fund managers &amp; institutional investors
        </p>
        <h1 className="max-w-3xl font-serif text-4xl leading-[1.1] text-ink md:text-5xl">
          Know how your investors want to vote, before the AGM invite lands.
        </h1>
        <p className="mt-6 max-w-measure text-base text-ink-light">
          Stewardship teams are judged on a voting record they often assemble
          after the fact. Tumelo gives fund managers and institutional
          investors the plumbing to apply policy consistently and show their
          work, meeting by meeting.
        </p>
      </section>

      <section className="border-y border-rule bg-paper-raised py-10">
        <div className="container-page grid grid-cols-1 gap-8 sm:grid-cols-3">
          {stats.map((s) => (
            <div key={s.label}>
              <p className="font-serif text-2xl text-ink">{s.value}</p>
              <p className="mt-1 text-sm text-ink-soft">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-page py-20">
        <h2 className="mb-10 max-w-measure font-serif text-2xl text-ink md:text-3xl">
          What changes across a voting cycle
        </h2>
        <div className="divide-y divide-rule border-y border-rule">
          {workflow.map((w) => (
            <div
              key={w.step}
              className="grid gap-3 py-8 md:grid-cols-[10rem_1fr_1.4fr] md:gap-10"
            >
              <p className="text-xs uppercase tracking-wide text-ink-soft">
                {w.step}
              </p>
              <h3 className="font-serif text-lg text-ink">{w.title}</h3>
              <p className="text-sm text-ink-light">{w.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-page pb-24">
        <div className="border border-ink/15 bg-paper-raised p-8 md:p-12">
          <h2 className="max-w-measure font-serif text-2xl text-ink">
            Bring your stewardship policy, we'll run it against every
            resolution.
          </h2>
          <p className="mt-4 max-w-measure text-sm text-ink-light">
            Most teams start with a single fund and their existing voting
            policy, then extend to segregated mandates once the record is
            proving itself out.
          </p>
          <a
            href="#contact"
            className="mt-6 inline-block border border-ink px-5 py-3 text-sm font-medium text-ink hover:bg-ink hover:text-paper"
          >
            Speak to our team
          </a>
        </div>
      </section>
    </div>
  );
}
