import { Link } from "react-router-dom";
import VoteRecord from "../components/VoteRecord";

const logos = ["Fidelity", "LGIM", "Glass Lewis", "PIRC", "Penfold", "Cushon"];

const products = [
  {
    name: "ProxySphere",
    tag: "Pass-through voting",
    description:
      "Gives every underlying investor in a pooled fund a route to vote their own shares, or hand that choice to a policy, without your operations team touching a spreadsheet.",
    points: [
      "Works for institutional and retail investors in the same fund",
      "Voting-policy agnostic — investors pick a policy or vote resolution by resolution",
      "Filters proposals by theme, so a climate policy only shows climate resolutions",
      "No vote goes un-voted: unvoted shares default to a stated policy, not silence",
    ],
    href: "/proxysphere",
  },
  {
    name: "ProxyBeacon",
    tag: "AI-driven proxy research",
    description:
      "Reads the resolutions ahead of a meeting, applies your stewardship policy consistently across every one, and flags the ones that actually need a person to look at them.",
    points: [
      "Aggregates issuer filings and resolution text automatically",
      "Applies custom stewardship policy the same way every time",
      "Surfaces exceptions and risk before the meeting, not after the vote",
      "Keeps research in-house instead of outsourcing every judgment call",
    ],
    href: "/fund-managers",
  },
];

export default function Home() {
  return (
    <div>
      <section className="container-page grid gap-12 py-16 md:grid-cols-2 md:items-center md:py-24">
        <div>
          <p className="mb-4 text-xs uppercase tracking-wide text-brass-dark">
            Voting infrastructure since 2018
          </p>
          <h1 className="font-serif text-4xl leading-[1.1] text-ink md:text-5xl">
            Every share your fund holds comes with a vote. Most of them go
            unread.
          </h1>
          <p className="mt-6 max-w-measure text-base text-ink-light">
            ProxySphere and ProxyBeacon give fund managers, pension schemes
            and institutional investors a working system for shareholder
            voting, instead of a compliance box nobody has time to open.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <a
              href="#contact"
              className="border border-ink bg-ink px-5 py-3 text-sm font-medium text-paper transition-colors hover:bg-ink-light"
            >
              Speak to our team
            </a>
            <Link
              to="/proxysphere"
              className="border border-ink/30 px-5 py-3 text-sm font-medium text-ink transition-colors hover:border-ink"
            >
              Explore ProxySphere
            </Link>
          </div>
        </div>
        <VoteRecord />
      </section>

      <section className="border-y border-rule bg-paper-raised py-10">
        <div className="container-page">
          <p className="mb-6 text-xs uppercase tracking-wide text-ink-soft">
            Who we work with
          </p>
          <div className="flex flex-wrap items-center gap-x-10 gap-y-4 text-ink-soft">
            {logos.map((l) => (
              <span key={l} className="font-serif text-lg">
                {l}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="container-page py-20">
        <div className="mb-12 max-w-measure">
          <h2 className="font-serif text-2xl text-ink md:text-3xl">
            Two products, one register of who owns what and how they voted.
          </h2>
        </div>
        <div className="grid gap-10 md:grid-cols-2 md:gap-16">
          {products.map((p) => (
            <div key={p.name} className="border-t-2 border-ink pt-6">
              <p className="text-xs uppercase tracking-wide text-brass-dark">
                {p.tag}
              </p>
              <h3 className="mt-2 font-serif text-xl text-ink">{p.name}</h3>
              <p className="mt-3 text-sm text-ink-light">{p.description}</p>
              <ul className="mt-5 space-y-2.5 text-sm text-ink-light">
                {p.points.map((pt) => (
                  <li key={pt} className="flex gap-2.5">
                    <span className="mt-1.5 h-1 w-1 shrink-0 bg-brass" />
                    <span>{pt}</span>
                  </li>
                ))}
              </ul>
              <Link
                to={p.href}
                className="mt-6 inline-block border-b border-ink text-sm font-medium text-ink hover:border-brass hover:text-brass-dark"
              >
                More on {p.name}
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-rule bg-ink py-20 text-paper">
        <div className="container-page grid gap-10 md:grid-cols-[1fr_1.4fr] md:items-center">
          <p className="font-serif text-3xl leading-tight text-paper/95">
            &ldquo;Tumelo is an extremely agile, collaborative, and
            results-focused team. They are a pleasure to work with.&rdquo;
          </p>
          <div>
            <p className="text-sm text-paper/70">
              Stuart Murphy, Head of Client Platforms, LGIM — on rolling out
              pass-through voting for a £2bn pension fund.
            </p>
            <a
              href="#"
              className="mt-4 inline-block border-b border-brass text-sm text-brass-light hover:text-paper"
            >
              Read the LGIM case study
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
